import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
	WidgetsFlutterBinding.ensureInitialized();
	SystemChrome.setPreferredOrientations([
	  DeviceOrientation.portraitUp,
	  DeviceOrientation.portraitDown,
	]);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Мои Цели',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      themeMode: ThemeMode.system,
      home: const HabitTrackerScreen(),
    );
  }
}

class HabitTrackerScreen extends StatefulWidget {
  const HabitTrackerScreen({super.key});

  @override
  State<HabitTrackerScreen> createState() => _HabitTrackerScreenState();
}

class _HabitTrackerScreenState extends State<HabitTrackerScreen> with WidgetsBindingObserver {
  final List<Map<String, dynamic>> _habits = [
    {'title': 'Выпить стакан воды', 'isDone': false, 'streak': 0, 'lastDoneDate': null},
    {'title': 'Сделать зарядку', 'isDone': false, 'streak': 0, 'lastDoneDate': null},
    {'title': 'Почитать 10 страниц', 'isDone': false, 'streak': 0, 'lastDoneDate': null},
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadHabits();
  }
  
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
  	if (state == AppLifecycleState.resumed) {
  	  _loadHabits();
      }
    }
    
    @override
    void dispose() {
    	WidgetsBinding.instance.removeObserver(this);
        super.dispose();
     }

  Future<void> _loadHabits() async {
    final prefs = await SharedPreferences.getInstance();
    
    final String today = DateTime.now().toIso8601String().split('T')[0];
    final String? lastSavedDate = prefs.getString('last_saved_date');
    
    final String? habitsString = prefs.getString('habits');
    if (habitsString != null) {
    	final List<dynamic> decoded = jsonDecode(habitsString);
        setState(() {
        	_habits.clear(); 
            _habits.addAll(decoded.map((e) => Map<String, dynamic>.from(e)));
         });
       }
       
       if (lastSavedDate != null && lastSavedDate != today) {
       	final String yesterday = DateTime.now().subtract(const Duration(days: 1)).toIso8601String().split('T')[0];
         setState(() {
         	for (var habit in _habits) {
         	  habit['isDone'] = false;
                 if (habit['lastDoneDate'] != yesterday) {
                 	habit['streak'] = 0;
                 }
               }
            });
           await _saveHabits(); 
        }
        
        await prefs.setString('last_saved_date', today); 
      }

  Future<void> _saveHabits() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('habits', jsonEncode(_habits));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Мои Цели', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Column(
        children: [
          
          Container(
             width: double.infinity,
             padding: const EdgeInsets.all(24.0),
             decoration: const BoxDecoration(
               color: Colors.indigo,
               borderRadius: BorderRadius.only(
                 bottomLeft: Radius.circular(30),
                 bottomRight: Radius.circular(30),
               ),
             ),
             child: Column(
               children: [
                 Text(
                   'Выполнено',
                   style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 16),
                 ),
                 const SizedBox(height: 8),
                 Text(
                   '${_habits.where((h) => h['isDone'] == true).length} из ${_habits.length}',
                   style: const TextStyle(
                     color: Colors.white,
                     fontSize: 32,
                     fontWeight: FontWeight.bold,
                   ),
                 ),
               ],
             ),
           ),
             
          Expanded(
            child: _habits.isEmpty
              ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.checklist_rtl, size: 80, color: Colors.grey[400]),
                    const SizedBox(height: 16),
                    Text(
                      'Пока нет привычек',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.grey[600]),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Нажмите +, чтобы добавить первую',
                      style: TextStyle(color: Colors.grey[500]),
                    ),
                  ],
                ),
              )
            : ListView.builder(
                itemCount: _habits.length,
                itemBuilder: (context, index) {
                  final habit = _habits[index];
                
                return Dismissible(
                  key: ObjectKey(habit),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    color: Colors.red,
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20.0),
                    child: const Icon(Icons.delete, color: Colors.white, size: 30),
                  ),
                  onDismissed: (direction) {
                    final removedHabit = _habits[index];
                    setState(() {
                      _habits.removeAt(index);
                    });
                    _saveHabits();
                    
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        duration: const Duration(seconds: 3),
                        backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
                        content: Text(
                          'Удалено: ${removedHabit['title']}',
                          style: TextStyle(color: Theme.of(context).colorScheme.onSurface),
                        ),
                        action: SnackBarAction(
                          label: 'Отменить',
                          textColor: Theme.of(context).colorScheme.primary,
                          onPressed: () {
                          	setState(() {
                          	  _habits.insert(index, removedHabit); 
                              });
                              _saveHabits();
                            },
                          ),
                        ),
                    );
                  },
                  child: Card(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: GestureDetector(
                      onLongPress: () {
                      	_showEditHabitDialog(index);
                      },
                    child: CheckboxListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      title: Text(
                        habit['title'],
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 18,
                          decoration: habit['isDone'] ? TextDecoration.lineThrough : null,
                          color: habit['isDone'] ? Colors.grey : Theme.of(context).colorScheme.onSurface,
                        ),
                      ),
                      subtitle: Row(
                        children: [
                          const Icon(Icons.local_fire_department, color: Colors.orange, size: 16),
                          const SizedBox(width: 4),
                          Text(
                            '${habit['streak'] ?? 0} дн. подряд',
                            style: TextStyle(
                              color: habit['isDone'] ? Colors.grey : Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                      value: habit['isDone'],
                      activeColor: Colors.indigo,
                      onChanged: (bool? value) {
                        setState(() {
                      	habit['isDone'] = value ?? false;
                          final String today = DateTime.now().toIso8601String().split('T')[0];
                          final String yesterday = DateTime.now().subtract(const Duration(days: 1)).toIso8601String().split('T')[0];
                          
                          if (habit['isDone'] == true) {
                          	if (habit['lastDoneDate'] != today) {
                          	  if (habit['lastDoneDate'] == yesterday) {
                          	    habit['streak'] = (habit['streak'] ?? 0) + 1;
                                } else {
                                  habit['streak'] = 1;
                                }
                                habit['lastDoneDate'] = today;
                              }
                            } else {
                            	if (habit['lastDoneDate'] == today) {
                            	  if ((habit['streak'] ?? 0) > 0) {
                            	    habit['streak'] = habit['streak'] - 1;
                                      } else {
                                	     habit['streak'] = 0;
                                       }
                                       habit['lastDoneDate'] = yesterday;
                                }
                              }
                      });
                      _saveHabits();
                      },
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    ),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: _showAddHabitDialog,
      backgroundColor: Colors.indigo,
      foregroundColor: Colors.white,
      icon: const Icon(Icons.add),
      label: const Text('Добавить'),
    ),
  );
}

  void _showAddHabitDialog() {
    final TextEditingController controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Новая привычка'),
          content: TextField(
            controller: controller,
            autofocus: true,
            maxLines: 3,
            minLines: 1,
            decoration: const InputDecoration(
              hintText: 'Название привычки',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Отмена'),
            ),
            ElevatedButton(
              onPressed: () {
                if (controller.text.isNotEmpty) {
                  setState(() {
                    _habits.add({
                      'title': controller.text,
                      'isDone': false,
                      'streak': 0,
                      'lastDoneDate': null,
                    });
                  });
                  _saveHabits();
                  Navigator.pop(context);
                }
              },
              child: const Text('Добавить'),
            ),
          ],
        );
      },
    );
  }
  void _showEditHabitDialog(int index) {
  	final habit = _habits[index];
      final TextEditingController controller = TextEditingController(text: habit['title']);
      
      showDialog(
        context: context,
        builder: (context) {
        	return AlertDialog(
              title: const Text('Редактировать привычку'),
              content: TextField(
                controller: controller,
                autofocus: true,
                maxLines: 3,
                minLines: 1,
                decoration: const InputDecoration(
                  hintText: 'Название привычки',
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Отмена'),
                ),
                ElevatedButton(
                  onPressed: () {
                  	if (controller.text.isNotEmpty) {
                  	  setState(() {
                  	    _habits[index]['title'] = controller.text;
                       });
                       _saveHabits();
                       Navigator.pop(context);
                     }
                   },
                   child: const Text('Сохранить'),
                 ),
               ],
             );
           },
         );
       }
}