import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Трекер привычек',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
        useMaterial3: true,
      ),
      home: const HabitTrackerScreen(),
    );
  }
}

class HabitTrackerScreen extends StatefulWidget {
  const HabitTrackerScreen({super.key});

  @override
  State<HabitTrackerScreen> createState() => _HabitTrackerScreenState();
}

class _HabitTrackerScreenState extends State<HabitTrackerScreen> {
  final List<Map<String, dynamic>> _habits = [
    {'title': 'Выпить стакан воды', 'isDone': false},
    {'title': 'Сделать зарядку', 'isDone': false},
    {'title': 'Почитать 10 страниц', 'isDone': false},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Мои привычки'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: ListView.builder(
        itemCount: _habits.length,
        itemBuilder: (context, index) {
          final habit = _habits[index];
          
          // Оборачиваем элемент в Dismissible для свайпа
          return Dismissible(
            key: ObjectKey(habit), // Уникальный ключ для каждой привычки
            direction: DismissDirection.endToStart, // Свайп только справа налево
            background: Container(
              color: Colors.red, // Красный фон при свайпе
              alignment: Alignment.centerRight,
              padding: const EdgeInsets.only(right: 20.0),
              child: const Icon(Icons.delete, color: Colors.white, size: 30),
            ),
            onDismissed: (direction) {
              // Когда свайп завершен, удаляем привычку из списка
              setState(() {
                _habits.removeAt(index);
              });
              // Показываем уведомление об удалении
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('${habit['title']} удалено')),
              );
            },
            child: CheckboxListTile(
              title: Text(habit['title']),
              value: habit['isDone'],
              onChanged: (bool? value) {
                setState(() {
                  habit['isDone'] = value ?? false;
                });
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddHabitDialog,
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showAddHabitDialog() {
    final TextEditingController controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Новая привычка'),
          content: TextField(
            controller: controller,
            autofocus: true,
            decoration: const InputDecoration(
              hintText: 'Например: Пить воду',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Отмена'),
            ),
            ElevatedButton(
              onPressed: () {
                if (controller.text.isNotEmpty) {
                  setState(() {
                    _habits.add({
                      'title': controller.text,
                      'isDone': false,
                    });
                  });
                  Navigator.pop(context);
                }
              },
              child: const Text('Добавить'),
            ),
          ],
        );
      },
    );
  }
}